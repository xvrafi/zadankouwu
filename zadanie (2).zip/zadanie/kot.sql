CREATE DATABASE kot;
use kot;



create table kot(
    Imie VARCHAR(90),
    Wiek int(70),
    Gatunek VARCHAR(10)
   
  
    
);


insert into kot (Imie,Wiek,Gatunek) VALUES
('Tosia','10','Pers'),
('Mania','5','Turecki');


